package Client;

public class Main_client {
    public static void main(String[] args) {
        new UI("欢迎：",300,200);
    }
}
